package com.event.management.toronto;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.event.management.constants.Constants;

public class TORManager {
	public String response;
	public TORDB torontoData;
	private static Logger logger;

	public TORManager() {
		super();
		torontoData = new TORDB();
		setLogger("logs/TOR.txt", Constants.TOR);
	}

	public String addEvent(String managerId, String eventId, String eventType, String eventCapacity) {
		if (eventType.equals(Constants.SEMINARS) || eventType.equals(Constants.CONFERENCES)
				|| eventType.equals(Constants.TRADE_SHOWS)) {
			if (eventId.substring(0, 3).trim().equals(managerId.substring(0, 3).trim())) {
				String output = "";
				if (eventId.substring(0, 3).trim().equals(Constants.TOR))
					output = generateOutput(managerId, eventId, eventType, eventCapacity, Constants.NONE,
							Constants.NONE, Constants.ADD_OPERATION,
							torontoData.addEvent(eventId, eventType, eventCapacity));
				else
					output = generateOutput(managerId, eventId, eventType, eventCapacity, Constants.NONE,
							Constants.NONE, Constants.ADD_OPERATION, false);
				return output;
			}
		}
		return generateOutput(managerId, eventId, eventType, eventCapacity, Constants.NONE, Constants.NONE,
				Constants.ADD_OPERATION, false);
	}

	public String removeEvent(String managerId, String eventId, String eventType) {
		if (eventType.equals(Constants.SEMINARS) || eventType.equals(Constants.CONFERENCES)
				|| eventType.equals(Constants.TRADE_SHOWS)) {
			if (eventId.substring(0, 3).trim().equals(managerId.substring(0, 3).trim())) {
				String output = "";
				if (eventId.substring(0, 3).trim().equals(Constants.TOR))
					output = generateOutput(managerId, eventId, eventType, Constants.NONE, Constants.NONE,
							Constants.NONE, Constants.REMOVE_OPERATION, torontoData.removeEvent(eventId, eventType));
				else
					output = generateOutput(managerId, eventId, eventType, Constants.NONE, Constants.NONE,
							Constants.NONE, Constants.REMOVE_OPERATION, false);
				return output.trim();
			}
		}
		return generateOutput(managerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
				Constants.REMOVE_OPERATION, false);
	}

	public String listEventAvailability(String managerId, String eventType) {
		if (eventType.trim().equals(Constants.SEMINARS) || eventType.trim().equals(Constants.CONFERENCES)
				|| eventType.trim().equals(Constants.TRADE_SHOWS)) {
			String temp = "";
			temp = torontoData.retrieveEvent(eventType).trim();
			temp += requestOnOtherServer(managerId, Constants.NONE, eventType, Constants.NONE,
					Constants.LOCAL_MONTREAL_PORT, Constants.LIST_OPERATION).trim();
			temp = temp + requestOnOtherServer(managerId, Constants.NONE, eventType, Constants.NONE,
					Constants.LOCAL_OTTAWA_PORT, Constants.LIST_OPERATION).trim();
			boolean status = temp.trim().isEmpty() ? false : true;
			return eventAvailableOutput(managerId, eventType, temp, Constants.LIST_OPERATION, status);
		} else {
			return eventAvailableOutput(managerId, eventType, "", Constants.LIST_OPERATION, false);
		}
	}

	public String requestOnOtherServer(String managerId, String eventId, String eventType, String eventCapacity,
			int port, String operation) {
		DatagramSocket datagramSocket = null;
		try {
			String requestData = managerId + "," + eventId + "," + eventType + "," + eventCapacity + "," + operation;
			datagramSocket = new DatagramSocket();
			DatagramPacket packetSend = new DatagramPacket(requestData.getBytes(), requestData.getBytes().length,
					InetAddress.getByName("localhost"), port);
			datagramSocket.send(packetSend);
			byte[] buffer = new byte[65535];
			DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
			datagramSocket.receive(reply);
			String response = new String(reply.getData());
			return response.trim();
		} catch (UnknownHostException e) {
			logger.info(e.getMessage());
		} catch (SocketException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		} finally {
			datagramSocket.close();
		}
		return "";
	}

	public String eventBooking(String customerId, String eventId, String eventType) {
		if (eventType.trim().equals(Constants.SEMINARS) || eventType.trim().equals(Constants.CONFERENCES)
				|| eventType.trim().equals(Constants.TRADE_SHOWS)) {
			StringBuilder count = new StringBuilder();
			if (!customerId.substring(0, 3).trim().equals(eventId.substring(0, 3).trim())) {
				if (customerId.trim().substring(0, 3).equals(Constants.TOR)) {
					count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
							Constants.LOCAL_MONTREAL_PORT, "countOperation") + ",");
					count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
							Constants.LOCAL_OTTAWA_PORT, "countOperation") + ",");
				} else if (customerId.trim().substring(0, 3).equals(Constants.MTL)) {
					count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
							Constants.LOCAL_TORONTO_PORT, "countOperation") + ",");
					count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
							Constants.LOCAL_OTTAWA_PORT, "countOperation") + ",");
				} else if (customerId.trim().substring(0, 3).equals(Constants.OTW)) {
					count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
							Constants.LOCAL_TORONTO_PORT, "countOperation") + ",");
					count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
							Constants.LOCAL_MONTREAL_PORT, "countOperation") + ",");
				}
				String[] split = count.toString().trim().split(",");
				int totalEve = 0;
				for (int i = 0; i < split.length; i++) {
					totalEve += Integer.parseInt(split[i].trim());
				}
				if (totalEve >= 3) {
					return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE,
							Constants.NONE, Constants.BOOK_OPERATION, false);
				}
			}

			if (customerId.substring(0, 3).trim().equals(eventId.substring(0, 3).trim())) {
				return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
						Constants.BOOK_OPERATION, torontoData.bookEvent(customerId, eventId, eventType));
			} else if (eventId.trim().substring(0, 3).equals(Constants.TOR)) {
				String temp = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
						Constants.LOCAL_TORONTO_PORT, Constants.BOOK_OPERATION);
				return !temp.trim().isEmpty() ? temp.trim()
						: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
								Constants.BOOK_OPERATION, false);// + " -- > " + count;
			} else if (eventId.trim().substring(0, 3).equals(Constants.MTL)) {
				String temp = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
						Constants.LOCAL_MONTREAL_PORT, Constants.BOOK_OPERATION);
				return !temp.trim().isEmpty() ? temp.trim()
						: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
								Constants.BOOK_OPERATION, false);// + " -- > " + count;
			} else if (eventId.trim().substring(0, 3).equals(Constants.OTW)) {
				String temp = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
						Constants.LOCAL_OTTAWA_PORT, Constants.BOOK_OPERATION);
				return !temp.trim().isEmpty() ? temp.trim()
						: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
								Constants.BOOK_OPERATION, false);// + " -- > " + count;
			} else {
				return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
						Constants.BOOK_OPERATION, false);
			}
		} else {
			return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
					Constants.BOOK_OPERATION, false);
		}
	}

	public String cancelBooking(String customerId, String eventId, String eventType) {
		if (eventType.trim().equals(Constants.SEMINARS) || eventType.trim().equals(Constants.CONFERENCES)
				|| eventType.trim().equals(Constants.TRADE_SHOWS)) {
			if (customerId.substring(0, 3).trim().equals(eventId.substring(0, 3).trim())) {
				return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
						Constants.CANCEL_OPERATION, torontoData.removeEvent(customerId, eventId, eventType));
			} else if (eventId.trim().substring(0, 3).equals(Constants.TOR)
					|| eventId.trim().substring(0, 3).equals(Constants.MTL)
					|| eventId.trim().substring(0, 3).equals(Constants.OTW)) {
				String tempEvent = eventId.trim().substring(0, 3).trim();
				switch (tempEvent) {
				case "TOR":
					String tempTOR = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
							Constants.LOCAL_TORONTO_PORT, Constants.CANCEL_OPERATION);
					return !tempTOR.trim().isEmpty() ? tempTOR
							: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE,
									Constants.NONE, Constants.CANCEL_OPERATION, false);
				case "MTL":
					String tempMTL = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
							Constants.LOCAL_MONTREAL_PORT, Constants.CANCEL_OPERATION);
					return !tempMTL.trim().isEmpty() ? tempMTL
							: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE,
									Constants.NONE, Constants.CANCEL_OPERATION, false);
				case "OTW":
					String tempOTW = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
							Constants.LOCAL_OTTAWA_PORT, Constants.CANCEL_OPERATION);
					return !tempOTW.trim().isEmpty() ? tempOTW
							: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE,
									Constants.NONE, Constants.CANCEL_OPERATION, false);

				}
			}
		}
		return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
				Constants.CANCEL_OPERATION, false);
	}

	public String getBookingSchedule(String customerId) {
		StringBuilder temp = new StringBuilder();
		temp.append(torontoData.getBookingSchedule(customerId.trim()));
		temp.append(requestOnOtherServer(customerId, Constants.NONE, Constants.NONE, Constants.NONE,
				Constants.LOCAL_MONTREAL_PORT, Constants.SCHEDULE_OPERATION).trim());
		temp.append(requestOnOtherServer(customerId, Constants.NONE, Constants.NONE, Constants.NONE,
				Constants.LOCAL_OTTAWA_PORT, Constants.SCHEDULE_OPERATION).trim());
		return temp.toString().trim().length() == 0
				? eventScheduleOutput(customerId, "", Constants.SCHEDULE_OPERATION, false)
				: eventScheduleOutput(customerId, temp.toString().trim(), Constants.SCHEDULE_OPERATION, true);
	}

	public String swapEvent(String customerID, String newEventID, String newEventType, String oldEventID,
			String oldEventType) {
		boolean existanceFlag = checkEventExistance(customerID, oldEventID, oldEventType);
		if (existanceFlag == false)
			return generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID, oldEventType,
					Constants.SWAP_OPERATION, false);
		if (customerID.trim().substring(0, 3).equals(newEventID.trim().substring(0, 3))) {
			boolean bookFlag = unpackJSON(swapEventBooking(customerID, newEventID, newEventType));
			if (bookFlag) {
				boolean cancelFlag = unpackJSON(swapCancelBooking(customerID, oldEventID, oldEventType));
				return cancelFlag
						? generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID, oldEventType,
								Constants.SWAP_OPERATION, true)
						: generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID, oldEventType,
								Constants.SWAP_OPERATION, false);
			} else {
				return generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID, oldEventType,
						Constants.SWAP_OPERATION, false);
			}
		} else if (!customerID.trim().substring(0, 3).equals(newEventID.trim().substring(0, 3))
				&& customerID.trim().substring(0, 3).equals(oldEventID.trim().substring(0, 3))) {
			boolean flag = checkMaximumLimt(customerID, newEventID);
			if (flag)
				return generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID, oldEventType,
						Constants.SWAP_OPERATION, false);
			boolean bookFlag = unpackJSON(swapEventBooking(customerID, newEventID, newEventType));
			if (bookFlag) {
				boolean cancelFlag = unpackJSON(swapCancelBooking(customerID, oldEventID, oldEventType));
				return cancelFlag
						? generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID, oldEventType,
								Constants.SWAP_OPERATION, true)
						: generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID, oldEventType,
								Constants.SWAP_OPERATION, false);
			} else {
				return generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID, oldEventType,
						Constants.SWAP_OPERATION, false);
			}
		} else if (!customerID.trim().substring(0, 3).equals(newEventID.trim().substring(0, 3))
				&& !customerID.trim().substring(0, 3).equals(oldEventID.trim().substring(0, 3))) {
			if (newEventID.trim().substring(6, newEventID.length())
					.equals(oldEventID.trim().substring(6, oldEventID.trim().length()))) {
				boolean bookFlag = unpackJSON(swapEventBooking(customerID, newEventID, newEventType));
				if (bookFlag) {
					boolean cancelFlag = unpackJSON(swapCancelBooking(customerID, oldEventID, oldEventType));
					return cancelFlag
							? generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID,
									oldEventType, Constants.SWAP_OPERATION, true)
							: generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID,
									oldEventType, Constants.SWAP_OPERATION, false);
				} else {
					return generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID,
							oldEventType, Constants.SWAP_OPERATION, false);
				}
			} else {
				boolean flag = checkMaximumLimt(customerID, newEventID);
				if (flag) {
					return generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID,
							oldEventType, Constants.SWAP_OPERATION, false);
				} else {
					boolean bookFlag = unpackJSON(swapEventBooking(customerID, newEventID, newEventType));
					if (bookFlag) {
						boolean cancelFlag = unpackJSON(swapCancelBooking(customerID, oldEventID, oldEventType));
						return cancelFlag
								? generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID,
										oldEventType, Constants.SWAP_OPERATION, true)
								: generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID,
										oldEventType, Constants.SWAP_OPERATION, false);
					} else {
						return generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID,
								oldEventType, Constants.SWAP_OPERATION, false);
					}
				}
			}
		}
		return generateOutput(customerID, newEventID, newEventType, Constants.NONE, oldEventID, oldEventType,
				Constants.SWAP_OPERATION, false);
	}

	public boolean checkMaximumLimt(String customerId, String eventId) {
		StringBuilder count = new StringBuilder();
		if (!customerId.substring(0, 3).trim().equals(eventId.substring(0, 3).trim())) {
			String tempServer = customerId.trim().substring(0, 3).trim();
			switch (tempServer) {
			case Constants.TOR:
				count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
						Constants.LOCAL_MONTREAL_PORT, "countOperation") + ",");
				count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
						Constants.LOCAL_OTTAWA_PORT, "countOperation") + ",");
				break;
			case Constants.MTL:
				count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
						Constants.LOCAL_TORONTO_PORT, "countOperation") + ",");
				count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
						Constants.LOCAL_OTTAWA_PORT, "countOperation") + ",");
				break;
			case Constants.OTW:
				count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
						Constants.LOCAL_TORONTO_PORT, "countOperation") + ",");
				count.append(requestOnOtherServer(customerId, eventId, Constants.NONE, Constants.NONE,
						Constants.LOCAL_MONTREAL_PORT, "countOperation") + ",");
				break;
			}
			String[] split = count.toString().trim().split(",");
			int totalEve = 0;
			for (int i = 0; i < split.length; i++) {
				totalEve += Integer.parseInt(split[i].trim());
			}
			if (totalEve >= 3) {
				return true;
			}
		}
		return false;
	}

	public boolean checkEventExistance(String customerID, String eventId, String eventType) {
		if (eventType.trim().equals(Constants.SEMINARS) || eventType.trim().equals(Constants.CONFERENCES)
				|| eventType.trim().equals(Constants.TRADE_SHOWS)) {
			if (customerID.substring(0, 3).trim().equals(eventId.substring(0, 3).trim())) {
				boolean temp = false;
				temp = torontoData.getEvent(customerID, eventId, eventType);
				return temp == false ? temp : true;
			} else if (eventId.trim().substring(0, 3).equals(Constants.TOR)) {
				String temp = requestOnOtherServer(customerID, eventId, eventType, Constants.NONE,
						Constants.LOCAL_TORONTO_PORT, "existanceOperation");
				return temp.trim().equals(Constants.DENIES) ? false : true;
			} else if (eventId.trim().substring(0, 3).equals(Constants.MTL)) {
				String temp = requestOnOtherServer(customerID, eventId, eventType, Constants.NONE,
						Constants.LOCAL_MONTREAL_PORT, "existanceOperation");
				return temp.trim().equals(Constants.DENIES) ? false : true;
			} else if (eventId.trim().substring(0, 3).equals(Constants.OTW)) {
				String temp = requestOnOtherServer(customerID, eventId, eventType, Constants.NONE,
						Constants.LOCAL_OTTAWA_PORT, "existanceOperation");
				return temp.trim().equals(Constants.DENIES) ? false : true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public String swapEventBooking(String customerId, String eventId, String eventType) {
		if (eventType.trim().equals(Constants.SEMINARS) || eventType.trim().equals(Constants.CONFERENCES)
				|| eventType.trim().equals(Constants.TRADE_SHOWS)) {
			if (customerId.substring(0, 3).trim().equals(eventId.substring(0, 3).trim())) {
				return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
						Constants.SWAP_OPERATION, torontoData.bookEvent(customerId, eventId, eventType));
			} else if (eventId.trim().substring(0, 3).equals(Constants.TOR)) {
				String temp = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
						Constants.LOCAL_TORONTO_PORT, Constants.BOOK_OPERATION);
				return !temp.trim().isEmpty() ? temp.trim()
						: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
								Constants.SWAP_OPERATION, false);
			} else if (eventId.trim().substring(0, 3).equals(Constants.MTL)) {
				String temp = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
						Constants.LOCAL_MONTREAL_PORT, Constants.BOOK_OPERATION);
				return !temp.trim().isEmpty() ? temp.trim()
						: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
								Constants.SWAP_OPERATION, false);
			} else if (eventId.trim().substring(0, 3).equals(Constants.OTW)) {
				String temp = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
						Constants.LOCAL_OTTAWA_PORT, Constants.BOOK_OPERATION);
				return !temp.trim().isEmpty() ? temp.trim()
						: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
								Constants.SWAP_OPERATION, false);
			} else {
				return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
						Constants.SWAP_OPERATION, false);
			}
		} else {
			return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
					Constants.SWAP_OPERATION, false);
		}
	}

	public String swapCancelBooking(String customerId, String eventId, String eventType) {

		if (eventType.trim().equals(Constants.SEMINARS) || eventType.trim().equals(Constants.CONFERENCES)
				|| eventType.trim().equals(Constants.TRADE_SHOWS)) {
			if (customerId.substring(0, 3).trim().equals(eventId.substring(0, 3).trim())) {
				return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
						Constants.SWAP_OPERATION, torontoData.removeEvent(customerId, eventId, eventType));
			} else if (eventId.trim().substring(0, 3).equals(Constants.TOR)) {
				String temp = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
						Constants.LOCAL_TORONTO_PORT, Constants.CANCEL_OPERATION);
				return !temp.trim().isEmpty() ? temp
						: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
								Constants.SWAP_OPERATION, false);
			} else if (eventId.trim().substring(0, 3).equals(Constants.MTL)) {
				String temp = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
						Constants.LOCAL_MONTREAL_PORT, Constants.CANCEL_OPERATION);
				return !temp.trim().isEmpty() ? temp
						: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
								Constants.SWAP_OPERATION, false);
			} else if (eventId.trim().substring(0, 3).equals(Constants.OTW)) {
				String temp = requestOnOtherServer(customerId, eventId, eventType, Constants.NONE,
						Constants.LOCAL_OTTAWA_PORT, Constants.CANCEL_OPERATION);
				return !temp.trim().isEmpty() ? temp
						: generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
								Constants.SWAP_OPERATION, false);
			} else {
				return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
						Constants.SWAP_OPERATION, false);
			}
		} else {
			return generateOutput(customerId, eventId, eventType, Constants.NONE, Constants.NONE, Constants.NONE,
					Constants.SWAP_OPERATION, false);
		}
	}

	static void setLogger(String location, String id) {
		try {
			logger = Logger.getLogger(id);
			FileHandler fileTxt = new FileHandler(location, true);
			SimpleFormatter formatterTxt = new SimpleFormatter();
			fileTxt.setFormatter(formatterTxt);
			logger.addHandler(fileTxt);
		} catch (Exception err) {
			logger.info("Couldn't Initiate Logger. Please check file permission");
		}
	}

	static String generateOutput(String id, String eventId, String eventType, String eventCapacity, String oldEventId,
			String oldEventType, String operation, boolean status) {
		JSONObject obj = new JSONObject();
		obj.put(Constants.ID, id.trim());
		obj.put(Constants.EVENT_ID, eventId.trim());
		obj.put(Constants.EVENT_TYPE, eventType.trim());
		obj.put(Constants.EVENT_CAPACITY, eventCapacity.trim());
		obj.put(Constants.OLD_EVENT_ID, oldEventId.trim());
		obj.put(Constants.OLD_EVENT_TYPE, oldEventType.trim());
		obj.put(Constants.OPERATION, operation.trim());
		obj.put(Constants.OPERATION_STATUS, status);
		return obj.toString();
	}

	static String eventAvailableOutput(String id, String eventType, String events, String operation, boolean status) {
		JSONObject obj = new JSONObject();
		obj.put(Constants.ID, id.trim());
		obj.put(Constants.EVENT_TYPE, eventType.trim());
		obj.put(Constants.LIST_EVENT_AVAILABLE, events.trim());
		obj.put(Constants.OPERATION, operation.trim());
		obj.put(Constants.OPERATION_STATUS, status);
		return obj.toString();
	}

	static String eventScheduleOutput(String id, String events, String operation, boolean status) {
		JSONObject obj = new JSONObject();
		obj.put(Constants.ID, id.trim());
		String[] splitEvents = events.trim().split(",");
		ArrayList<String> temp = new ArrayList<String>();
		for (int i = 0; i < splitEvents.length; i++) {
			temp.add(splitEvents[i].replaceAll("\\s+", "").trim());
		}
		Collections.sort(temp);
		obj.put(Constants.LIST_EVENT_SCHEDULE, temp.toString().trim());
		obj.put(Constants.OPERATION, operation.trim());
		obj.put(Constants.OPERATION_STATUS, status);
		return obj.toString();
	}

	static boolean unpackJSON(String jsonString) {
		Object obj = null;
		try {
			obj = new JSONParser().parse(jsonString.trim());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject jsonObject = (JSONObject) obj;
		return Boolean.parseBoolean(jsonObject.get(Constants.OPERATION_STATUS).toString().trim());
	}
}

class TORDB {
	HashMap<String, HashMap<String, HashMap<String, String>>> data;
	String serverName;

	public TORDB() {
		data = new HashMap<>();
		data.put(Constants.CONFERENCES, new HashMap<>());
		data.put(Constants.SEMINARS, new HashMap<>());
		data.put(Constants.TRADE_SHOWS, new HashMap<>());
	}

	public synchronized boolean removeEvent(String eventId, String eventType) {
		if (data.containsKey(eventType)) {
			HashMap<String, HashMap<String, String>> newValue = data.get(eventType);
			if (newValue.containsKey(eventId)) {
				data.get(eventType).remove(eventId);
				return true;
			}
		}
		return false;
	}

	public synchronized String retrieveEvent(String eventType) {
		if (data.containsKey(eventType)) {
			HashMap<String, HashMap<String, String>> temp = data.get(eventType);
			if (temp.size() == 0) {
				return "";
			} else {
				StringBuilder str = new StringBuilder();
				for (Entry<String, HashMap<String, String>> entry : temp.entrySet()) {
					if (Integer.parseInt(entry.getValue().get(Constants.CAPACITY)) >= Integer
							.parseInt(entry.getValue().get(Constants.TOTAL_BOOKING)))
						str.append(
								entry.getKey() + " "
										+ (Integer.parseInt(entry.getValue().get(Constants.CAPACITY))
												- Integer.parseInt(entry.getValue().get(Constants.TOTAL_BOOKING)))
										+ ",");
				}
				return str.toString().trim();
			}
		} else {
			return "";
		}
	}

	public synchronized boolean addEvent(String eventId, String eventtype, String eventCapacity) {
		if (data.containsKey(eventtype)) {
			HashMap<String, HashMap<String, String>> newValue = data.get(eventtype);
			if (newValue.containsKey(eventId)) {
				HashMap<String, String> newList = newValue.get(eventId);
				newList.replace(Constants.CAPACITY, newList.get(Constants.CAPACITY), eventCapacity);
				newList.replace(Constants.TOTAL_BOOKING, newList.get(Constants.TOTAL_BOOKING),
						newList.get(Constants.TOTAL_BOOKING));
				newList.replace(Constants.CUSTOMER_ID, newList.get(Constants.CUSTOMER_ID),
						newList.get(Constants.CUSTOMER_ID));
				newValue.replace(eventId, data.get(eventtype).get(eventId), newList);
				data.replace(eventtype, data.get(eventtype), newValue);
				return true;
			} else {
				HashMap<String, String> temp = new HashMap<>();
				temp.put(Constants.CAPACITY, eventCapacity);
				temp.put(Constants.TOTAL_BOOKING, "0");
				temp.put(Constants.CUSTOMER_ID, "");
				newValue.put(eventId, temp);
				data.replace(eventtype, data.get(eventtype), newValue);
				return true;
			}
		}
		return false;
	}

	public synchronized boolean bookEvent(String customerID, String eventId, String eventType) {
		if (data.containsKey(eventType)) {
			HashMap<String, HashMap<String, String>> typeData = data.get(eventType);
			if (typeData.size() == 0) {
				return false;
			} else {
				if (typeData.containsKey(eventId)) {
					HashMap<String, String> currentEvent = typeData.get(eventId);
					if (Integer.parseInt(currentEvent.get(Constants.CAPACITY)) == Integer
							.parseInt(currentEvent.get(Constants.TOTAL_BOOKING))) {
						return false;
					} else {
						StringBuilder customers = new StringBuilder(currentEvent.get(Constants.CUSTOMER_ID));
						if (currentEvent.get(Constants.CUSTOMER_ID).contains(customerID)) {
							return false;
						}
						customers.append(customerID.trim());
						currentEvent.replace(Constants.CUSTOMER_ID, customers.toString().trim() + ",");
						currentEvent.replace(Constants.CAPACITY, currentEvent.get(Constants.CAPACITY),
								Integer.toString(Integer.parseInt(currentEvent.get(Constants.CAPACITY))));
						currentEvent.replace(Constants.TOTAL_BOOKING, currentEvent.get(Constants.TOTAL_BOOKING),
								Integer.toString(Integer.parseInt(currentEvent.get(Constants.TOTAL_BOOKING)) + 1));
						typeData.replace(eventId, typeData.get(eventId), currentEvent);
						data.replace(eventType, data.get(eventType), typeData);
						return true;
					}
				} else {
					return false;
				}
			}
		} else {
			return false;
		}
	}

	public synchronized boolean removeEvent(String customerID, String eventId, String eventType) {
		if (data.containsKey(eventType)) {
			HashMap<String, HashMap<String, String>> typeData = data.get(eventType);
			if (typeData.size() == 0) {
				return false;
			} else {
				if (typeData.containsKey(eventId)) {
					HashMap<String, String> currentEvent = typeData.get(eventId);
					if (Integer.parseInt(currentEvent.get(Constants.TOTAL_BOOKING)) == 0) {
						return false;
					} else {
						StringBuilder customers = new StringBuilder(currentEvent.get(Constants.CUSTOMER_ID));
						if (!currentEvent.get(Constants.CUSTOMER_ID).contains(customerID)) {
							return false;
						}
						currentEvent.replace(Constants.CUSTOMER_ID,
								customers.toString().replace(customerID.trim() + ",", ""));
						currentEvent.replace(Constants.CAPACITY, currentEvent.get(Constants.CAPACITY),
								Integer.toString(Integer.parseInt(currentEvent.get(Constants.CAPACITY))));
						currentEvent.replace(Constants.TOTAL_BOOKING, currentEvent.get(Constants.TOTAL_BOOKING),
								Integer.toString(Integer.parseInt(currentEvent.get(Constants.TOTAL_BOOKING)) - 1));
						typeData.replace(eventId, typeData.get(eventId), currentEvent);
						data.replace(eventType, data.get(eventType), typeData);
						return true;
					}
				} else {
					return false;
				}
			}
		} else {
			return false;
		}
	}

	public synchronized String getBookingSchedule(String customerId) {
		StringBuilder customers = new StringBuilder();
		for (Entry<String, HashMap<String, HashMap<String, String>>> types : data.entrySet()) {
			for (Entry<String, HashMap<String, String>> events : types.getValue().entrySet()) {
				if (events.getValue().get(Constants.CUSTOMER_ID).contains(customerId.trim())) {
					customers.append(types.getKey() + " = " + events.getKey() + ",");
				}
			}
		}
		return customers.length() == 0 ? "" : customers.toString();
	}

	public synchronized String getBookingCount(String customerId, String eventType) {
		int count = 0;
		String month = eventType.trim().substring(6, eventType.trim().length());
		for (Entry<String, HashMap<String, HashMap<String, String>>> types : data.entrySet()) {
			for (Entry<String, HashMap<String, String>> events : types.getValue().entrySet()) {
				if (events.getValue().get(Constants.CUSTOMER_ID).trim().contains(customerId.trim())
						&& events.getKey().substring(6, events.getKey().trim().length()).trim().equals(month.trim())) {
					count++;
				}
			}
		}
		return Integer.toString(count);
	}

	public synchronized boolean getEvent(String customerId, String eventId, String eventType) {
		if (data.containsKey(eventType)) {
			HashMap<String, HashMap<String, String>> typeData = data.get(eventType);
			if (typeData.size() == 0) {
				return false;
			} else {
				if (typeData.containsKey(eventId)) {
					HashMap<String, String> currentEvent = typeData.get(eventId);
					return currentEvent.get(Constants.CUSTOMER_ID).contains(customerId.trim());
				}
			}
		}
		return false;
	}

	public HashMap<String, HashMap<String, HashMap<String, String>>> getServerData() {
		return data;
	}

	public void setServerData(HashMap<String, HashMap<String, HashMap<String, String>>> data) {
		this.data = data;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
}
