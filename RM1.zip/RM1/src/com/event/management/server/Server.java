package com.event.management.server;

public class Server {

}
